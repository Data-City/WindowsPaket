Voraussetzungen:
Node.js und npm installiert (https://nodejs.org)
Das Node-Modul grunt ist installiert (http://gruntjs.com/)
Java 8 ist installiert